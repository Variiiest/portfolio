# Open Zip file 
## Please assure node installed in PC

1: Run <code> npm install </code>

2: After this run  <code>npm start </code>



## Solved Problems


1: Homepage have resume 

2: Main Skills : As menu

3: Footer : 3 Columns

4: Router to create Link

5: Puplic api to fill the page

6: Footer and Nav are Static

7: Used tailwindcss So theme will easy to setup


